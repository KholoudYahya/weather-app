import { useState } from "react";
import "./App.css";
import axios from "axios";
import { nanoid } from 'nanoid';

const Header = () => {
	return (
		<div >
			<h1 className=' header'>React Projects</h1>
		</div>
	);
};

export default Header;
